# PIYUSH PASWAN — Fashion Model Portfolio

Premium static fashion-editorial portfolio built with HTML5, CSS3 and vanilla JavaScript.

## Included photographs

The real photographs supplied in the conversation are included in `images/`.

- `photo-03.jpg` — homepage hero (required)
- `photo-02.jpg` — about / portfolio
- `photo-04.jpg` — portfolio
- `photo-05.jpg` — selected work / portfolio
- `photo-06.jpg` — portfolio
- `photo-07.jpg` — portfolio
- `photo-08.jpg` — portfolio
- `photo-09.jpg` — additional portfolio / social image

No stock images and no AI-generated model photographs are used.

## Edit later

All profile details, missing measurements and experience placeholders are directly editable in `index.html`.

Missing values intentionally remain:
- WAIST — ADD WAIST
- HIPS — ADD HIPS
- SHOE SIZE — ADD SHOE SIZE
- HAIR — ADD HAIR COLOR

## Netlify

This is a static site. No build command is required.

Upload the complete folder to Netlify Drop, or connect the folder/repository to Netlify.

## Important

`photo-03.jpg` is the homepage hero. `hero.jpg` is not used anywhere.
