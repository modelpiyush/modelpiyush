const header = document.getElementById("site-header");
const toggle = document.querySelector(".menu-toggle");
const nav = document.getElementById("site-menu");

window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 30);
}, { passive: true });

toggle.addEventListener("click", () => {
  const open = toggle.getAttribute("aria-expanded") === "true";
  toggle.setAttribute("aria-expanded", String(!open));
  toggle.setAttribute("aria-label", open ? "Open menu" : "Close menu");
  nav.classList.toggle("open", !open);
  document.body.classList.toggle("menu-open", !open);
});

nav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open menu");
    nav.classList.remove("open");
    document.body.classList.remove("menu-open");
  });
});

const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));

const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const heroImage = document.querySelector(".hero-media img");

if (!prefersReducedMotion && heroImage) {
  window.addEventListener("scroll", () => {
    const y = Math.min(window.scrollY * 0.045, 34);
    heroImage.style.transform = `scale(1.025) translateY(${y}px)`;
  }, { passive: true });
}

const items = [...document.querySelectorAll(".gallery-item")];
const lightbox = document.getElementById("lightbox");
const lbImg = document.getElementById("lightbox-image");
const lbCat = document.getElementById("lightbox-category");
const lbTitle = document.getElementById("lightbox-title");
const closeButton = document.querySelector(".lightbox-close");
let current = 0;
let touchStartX = 0;
let lastFocused = null;

function showImage(index) {
  current = (index + items.length) % items.length;
  const item = items[current];
  const image = item.querySelector("img");
  lbImg.src = image.currentSrc || image.src;
  lbImg.alt = image.alt;
  lbCat.textContent = item.querySelector(".image-meta small")?.textContent || "PORTFOLIO";
  lbTitle.textContent = item.querySelector(".image-meta strong")?.textContent || `FRAME / ${current + 1}`;
}

function openLightbox(index) {
  lastFocused = document.activeElement;
  showImage(index);
  lightbox.classList.add("open");
  lightbox.setAttribute("aria-hidden", "false");
  document.body.classList.add("menu-open");
  closeButton.focus();
}

function closeLightbox() {
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden", "true");
  document.body.classList.remove("menu-open");
  if (lastFocused) lastFocused.focus();
}

items.forEach((item, index) => {
  item.addEventListener("click", () => openLightbox(index));
});

document.querySelector(".lightbox-close").addEventListener("click", closeLightbox);
document.querySelector(".lightbox-prev").addEventListener("click", () => showImage(current - 1));
document.querySelector(".lightbox-next").addEventListener("click", () => showImage(current + 1));

document.addEventListener("keydown", event => {
  if (!lightbox.classList.contains("open")) return;
  if (event.key === "Escape") closeLightbox();
  if (event.key === "ArrowLeft") showImage(current - 1);
  if (event.key === "ArrowRight") showImage(current + 1);
});

lightbox.addEventListener("click", event => {
  if (event.target === lightbox) closeLightbox();
});

lightbox.addEventListener("touchstart", event => {
  touchStartX = event.changedTouches[0].screenX;
}, { passive: true });

lightbox.addEventListener("touchend", event => {
  const dx = event.changedTouches[0].screenX - touchStartX;
  if (Math.abs(dx) > 45) showImage(dx < 0 ? current + 1 : current - 1);
}, { passive: true });
